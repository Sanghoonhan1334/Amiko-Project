# 마리아 작업 요청 문서

이 폴더는 마리아에게 전달할 작업 요청 및 관련 문서들을 모아둔 곳입니다.

## 📋 작업 요청 사항

1. **정책 + 동의합니다 UI** (12월까지)
2. **결제시스템 + 커뮤니티에 강의 탭 만들기**

---

## 📁 문서 목록

### 1. 작업 분석 및 요청사항
- **`MARIA_TASK_ANALYSIS.md`** - 마리아 작업 요청 분석 및 답변
  - 영상통화 1:1 상담 결제 시스템 (Phase 2)
  - 커뮤니티 강의실 + 결제 시스템 (Phase 1)
  - 우선순위 및 작업 순서

### 2. 강의 플랫폼 제안
- **`LECTURE_PLATFORM_PROPOSAL.md`** - 강의 플랫폼 통합 제안
  - 하이브리드 방식 (우리 사이트 + Zoom)
  - 구현 방법 및 데이터베이스 스키마
  - UI 플로우

### 3. Zoom 통합 가이드
- **`ZOOM_INTEGRATION.md`** - Zoom 통합 가이드
  - 간단한 링크 방식 (추천)
  - Zoom API 자동 생성 (선택사항)
  - 구현 코드 예시

### 4. PayPal 결제 시스템 스키마
- **`paypal-payment-schema.sql`** - 전체 스키마 생성 스크립트
- **`PAYPAL_SCHEMA_GUIDE.md`** - 상세 가이드 문서
- **`PAYPAL_SCHEMA_SUMMARY.md`** - 요약 문서
- **`paypal-test-data.sql`** - 테스트 데이터 삽입 스크립트

---

## 🚀 빠른 시작

### 1. 데이터베이스 스키마 생성
```bash
# Supabase Dashboard > SQL Editor에서 실행
paypal-payment-schema.sql
```

### 2. 테스트 데이터 삽입 (선택)
```bash
# Supabase Dashboard > SQL Editor에서 실행
paypal-test-data.sql
```

### 3. 작업 순서
1. **Phase 1 (12월까지 - 급함)**
   - 정책 + 동의합니다 UI
   - 커뮤니티 강의실 + 결제 시스템

2. **Phase 2 (영상통화 UI 완성 후 - 1월말 이후)**
   - 영상통화 1:1 상담 PayPal 결제 연결
   - 참고: 사용자가 Agora로 직접 개발 중 (1월말 완료 예정)

---

## 📝 참고 파일

기존 코드 참고:
- `src/app/call/[meetingId]/page.tsx` - Google Meet 참여 페이지 (Zoom 참고용)
- `src/app/payments/checkout/page.tsx` - 결제 페이지
- `src/components/payments/PayPalPaymentButton.tsx` - PayPal 결제 버튼
- `src/components/main/app/community/CommunityTab.tsx` - 커뮤니티 탭

---

**작성일:** 2025-12-09
